from django import forms


class ImageUploadWCForm(forms.Form):

    print("Image upload from WC form.")
    imagewc = forms.ImageField(label='Select a file')
    print("Hi in Webcam ", imagewc)
