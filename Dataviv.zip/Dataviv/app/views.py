from django.shortcuts import render
from django.http import HttpResponse
from django.views.decorators.csrf import csrf_exempt
from .forms import ImageUploadWCForm
import json
import base64
import random
import string
from .models import *
from django.http import JsonResponse

from django.views import View
from .models import Profile_Image
from django.views.decorators.csrf import csrf_exempt


# Create your views here.

from django.views.decorators.csrf import csrf_exempt


def upload_webcam(request):

    print("in upload WBCAM ")
    if request.method == 'POST':
        form = ImageUploadWCForm(request.POST, request.FILES)
        # print "FILES", request.FILES

        if form.is_multipart():
            uploadFile = save_filewc(request.FILES['imagewc'])
            print('vALID iMAGE')
        else:
            print('Invalid image')

    else:
        form = ImageUploadWCForm()

    return render(request, 'app/home.html')


def save_filewc(file, path=''):

    filename = "uploadedPicWC.jpg"
    fd = open('%s/%s' % ('MEDIA_ROOT', str(path) + str(filename)), 'wb')
    print("fd", fd)
    print("str(path)", str(path))
    print("str(filename)", str(filename))
    for chunk in file.chunks():
        fd.write(chunk)
    fd.close()
