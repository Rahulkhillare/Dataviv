from django.db import models

# Create your models here.


class Profile_Image(models.Model):

    user_image = models.ImageField(upload_to='static/images')
